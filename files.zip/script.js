/* RankApex AI — App Logic v2 */
(function(){
  'use strict';

  const FREE_LIMIT = 5;
  const PATREON_URL = 'https://www.patreon.com/AeraDevelopers/posts/get-unlimited-to-162298122?utm_source=clipboard_copy&utm_medium=copyLink&utm_campaign=postshare_fan&utm_content=web_share';

  // Credentials stored obfuscated — not displayed anywhere in the UI
  const _a = atob('ZGVtbw==');           // demo
  const _b = atob('cmFua2FwZXgyMDI1'); // rankapex2025

  const $ = (s,r=document) => r.querySelector(s);
  const $$ = (s,r=document) => Array.from(r.querySelectorAll(s));

  // ── STATE ──────────────────────────────────────────────
  const state = {
    get uses(){ return parseInt(localStorage.getItem('rax_uses')||'0',10); },
    set uses(v){ localStorage.setItem('rax_uses', String(v)); },
    get pro(){ return localStorage.getItem('rax_pro')==='true'; },
    set pro(v){ localStorage.setItem('rax_pro', v?'true':'false'); }
  };

  function updateUsageDisplay(){
    const left = Math.max(0, FREE_LIMIT - state.uses);
    const chip = $('#usageChip');
    const pillCount = $('#usagePillCount');
    const pill = $('#usagePill');

    if(state.pro){
      if(chip) chip.innerHTML = '<span>⚡</span> Unlimited';
      if(pillCount) pillCount.textContent = '∞';
      if(pill) pill.innerHTML = '<span>⚡</span> <strong>Unlimited</strong>&nbsp;access';
      $('#proBadge').classList.remove('hidden');
    } else {
      if(chip){ $('#usageCount') && ($('#usageCount').textContent = left); }
      if(pillCount) pillCount.textContent = left;
      $('#proBadge').classList.add('hidden');
    }
  }

  function canUse(){
    if(state.pro) return true;
    if(state.uses >= FREE_LIMIT){ openModal('paywallModal'); return false; }
    return true;
  }
  function consumeUse(){
    if(state.pro) return;
    state.uses = state.uses + 1;
    updateUsageDisplay();
    if(state.uses >= FREE_LIMIT){ setTimeout(()=>openModal('paywallModal'), 500); }
  }

  // ── MODALS ─────────────────────────────────────────────
  function openModal(id){ const m = $('#'+id); if(m){ m.classList.add('open'); document.body.style.overflow='hidden'; } }
  function closeModal(el){ el.classList.remove('open'); document.body.style.overflow=''; }
  $$('.modal').forEach(m => m.addEventListener('click', e=>{ if(e.target===m) closeModal(m); }));
  $$('[data-close]').forEach(b => b.addEventListener('click', ()=>closeModal(b.closest('.modal'))));

  // ── LOGIN ──────────────────────────────────────────────
  // Hidden trigger: Ctrl + Shift + P  OR  clicking loginBtn
  $('#loginBtn').addEventListener('click', ()=>{
    if(state.pro){ toast('You already have Lifetime Pro access ⚡'); return; }
    openModal('loginModal');
  });
  document.addEventListener('keydown', e=>{
    if(e.ctrlKey && e.shiftKey && e.key==='P'){
      e.preventDefault();
      if(state.pro){ toast('Already a Pro member ⚡'); return; }
      openModal('loginModal');
    }
  });

  $('#loginForm').addEventListener('submit', e=>{
    e.preventDefault();
    const u = $('#loginUser').value.trim();
    const p = $('#loginPass').value;
    if(u===_a && p===_b){
      state.pro = true;
      updateUsageDisplay();
      closeModal($('#loginModal'));
      toast('Welcome! Lifetime access activated ⚡');
    } else {
      $('#loginError').classList.remove('hidden');
    }
  });

  // ── NAV ────────────────────────────────────────────────
  $('#hamburger').addEventListener('click', ()=>$('.primary-nav').classList.toggle('open'));
  $$('.primary-nav a').forEach(a => a.addEventListener('click', ()=>$('.primary-nav').classList.remove('open')));

  // Sticky header shadow on scroll
  window.addEventListener('scroll', ()=>{
    $('#siteHeader').classList.toggle('scrolled', window.scrollY > 20);
  }, {passive:true});

  $('#year').textContent = new Date().getFullYear();

  // ── CONTACT ────────────────────────────────────────────
  $('#contactForm').addEventListener('submit', e=>{
    e.preventDefault();
    e.target.reset();
    toast('Message sent! We\'ll reply within 24 hours.');
  });

  // ── TOAST ──────────────────────────────────────────────
  let toastTimer;
  function toast(msg){
    const t = $('#toast');
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(()=>t.classList.remove('show'), 3400);
  }

  // ── HELPERS ────────────────────────────────────────────
  function hash(s){
    let h=0;
    for(let i=0;i<s.length;i++){ h=((h<<5)-h)+s.charCodeAt(i); h|=0; }
    return Math.abs(h);
  }
  function metricBar(label,val,max=100){
    const pct = Math.min(100, Math.round((val/max)*100));
    return `<div class="metric"><div class="v">${val}</div><div class="l">${label}</div><div class="bar"><span style="width:${pct}%"></span></div></div>`;
  }
  function scoreColor(s){ return s>=75?'score-good':s>=50?'score-avg':'score-poor'; }

  // ── TOOLS ──────────────────────────────────────────────
  const tools = {

    /* ===== DEEP SITE HEALTH AUDITOR ===== */
    siteanalyzer: {
      title: 'Deep Site Health Auditor',
      sub: 'Paste any URL for a detailed 100-point SEO health report with prioritized fixes.',
      render: ()=>`
        <form class="tool-form" data-action="siteanalyzer">
          <label>Website URL
            <input name="url" type="url" required placeholder="https://yourwebsite.com" autocomplete="off">
          </label>
          <label>Industry (optional — improves accuracy)
            <select name="industry">
              <option value="">— Select industry —</option>
              <option>E-commerce</option><option>SaaS / Software</option>
              <option>Blog / Content</option><option>Local Business</option>
              <option>Agency / Services</option><option>Health & Wellness</option>
              <option>Finance</option><option>Education</option><option>Real Estate</option>
            </select>
          </label>
          <button class="btn btn-primary" type="submit">🩺 Run Deep Audit</button>
        </form>
        <div id="out" class="hidden"></div>`,
      run:(form,out)=>{
        const url = form.url.value.trim();
        const ind = form.industry.value || 'General';
        const h = hash(url);
        let hostname = url.replace(/https?:\/\//,'').split('/')[0];
        const hasWWW = hostname.startsWith('www.');
        const hasSub = hostname.split('.').length > 2 && !hasWWW;
        const urlLen = url.length;
        const hasKeyword = /[-a-z]{4,}/.test(hostname);
        const hasHTTPS = url.startsWith('https');
        const pathDepth = (url.match(/\//g)||[]).length - 2;

        // Scoring
        const technical = Math.min(100, 45 + (h%35) + (hasHTTPS?15:0) - (pathDepth>4?10:0));
        const onpage    = Math.min(100, 40 + (h%40) + (hasKeyword?12:0));
        const content   = Math.min(100, 38 + (h%45) + (urlLen<40?10:0));
        const perf      = Math.min(100, 42 + (h%38) + (!hasSub?10:0));
        const overall   = Math.round((technical+onpage+content+perf)/4);
        const scoreClass = scoreColor(overall);

        // Generate issues based on simulated checks
        const allIssues = [
          {p:'high', icon:'🔴', title:'Missing H1 tag detected', desc:'Your page appears to lack a primary H1 heading. This is one of Google\'s strongest on-page signals. Add exactly one H1 containing your target keyword.'},
          {p:'high', icon:'🔴', title:'Meta description absent', desc:'No meta description found. This is the text Google shows in search results. Write a 150-160 character description with your main keyword and a clear call-to-action.'},
          {p:'high', icon:'🔴', title:'Page load speed below 3s threshold', desc:'Core Web Vitals data suggests slow LCP (Largest Contentful Paint). Compress images with WebP, enable browser caching, and use a CDN to fix this quickly.'},
          {p:'med',  icon:'🟡', title:'Images missing alt text', desc:'Several images lack descriptive alt attributes. Alt text helps visually impaired users and gives Google important keyword context for image indexing.'},
          {p:'med',  icon:'🟡', title:'Internal linking structure weak', desc:'Pages appear to have fewer than 3 internal links each. A strong internal link structure helps Google discover your pages and distributes page authority effectively.'},
          {p:'med',  icon:'🟡', title:'Canonical tag not implemented', desc:'No canonical URL tag detected. Without canonicals, duplicate content (e.g., with and without www) can split your ranking signals and confuse crawlers.'},
          {p:'med',  icon:'🟡', title:'Schema markup missing', desc:'No structured data (JSON-LD) detected. Schema markup enables rich results in Google (star ratings, FAQs, breadcrumbs) and significantly improves click-through rates.'},
          {p:'low',  icon:'🟢', title:'Title tag could be optimized', desc:'Your title tag is either too short, too long, or doesn\'t lead with your primary keyword. Aim for 50-60 characters with your main keyword in the first 3 words.'},
          {p:'low',  icon:'🟢', title:'Mobile viewport tag check', desc:'Ensure your viewport meta tag is set to width=device-width, initial-scale=1. Without it, Google\'s mobile-first indexing may penalize your site.'},
          {p:'low',  icon:'🟢', title:'Open Graph tags incomplete', desc:'Social sharing tags (og:title, og:description, og:image) are incomplete. These control how your pages look when shared on LinkedIn, Twitter, and Facebook.'},
          {p:'low',  icon:'🟢', title:'Sitemap.xml not confirmed', desc:`Ensure a sitemap is live at ${hasWWW?url.split('/')[0]+'//'+hostname:'https://'+hostname}/sitemap.xml and submitted in Google Search Console.`},
          {p:'high', icon:'🔴', title:'No SSL / HTTPS detected', desc:'Your site appears to use HTTP instead of HTTPS. Google uses HTTPS as a ranking signal and Chrome marks HTTP sites as "Not Secure" — this actively hurts conversions and rankings.'},
        ];
        // Pick 5-7 issues deterministically based on hash
        const selected = allIssues.filter((_,i)=> (h + i) % (allIssues.length/2) < 3 || i < 2 ).slice(0,6);
        if(hasHTTPS){ selected.splice(selected.findIndex(x=>x.title.includes('SSL')),1); }

        const issueHTML = (selected.filter(x=>x!==undefined)).map(issue=>`
          <div class="issue-item issue-${issue.p==='high'?'high':issue.p==='med'?'med':'low'}">
            <div class="issue-icon">${issue.icon}</div>
            <div class="issue-body"><strong>${issue.title}</strong><p>${issue.desc}</p></div>
          </div>`).join('');

        out.innerHTML = `
          <div class="audit-header">
            <div class="score-ring ${scoreClass}">
              <div class="sval">${overall}</div>
              <div class="slabel">/ 100</div>
            </div>
            <div class="audit-cats">
              <div class="audit-cat">
                <span class="cat-label">Technical</span>
                <div class="bar" style="flex:1"><span style="width:${technical}%"></span></div>
                <span class="cat-val">${technical}</span>
              </div>
              <div class="audit-cat">
                <span class="cat-label">On-Page SEO</span>
                <div class="bar" style="flex:1"><span style="width:${onpage}%"></span></div>
                <span class="cat-val">${onpage}</span>
              </div>
              <div class="audit-cat">
                <span class="cat-label">Content</span>
                <div class="bar" style="flex:1"><span style="width:${content}%"></span></div>
                <span class="cat-val">${content}</span>
              </div>
              <div class="audit-cat">
                <span class="cat-label">Performance</span>
                <div class="bar" style="flex:1"><span style="width:${perf}%"></span></div>
                <span class="cat-val">${perf}</span>
              </div>
            </div>
          </div>
          <h4 style="margin-bottom:12px;font-size:.85rem;text-transform:uppercase;letter-spacing:.07em;color:var(--muted)">Issues Found — Ranked by Impact</h4>
          <div class="issue-list">${issueHTML}</div>
          <div class="tool-output" style="margin-top:18px">
            <strong>Next Steps for ${hostname} (${ind}):</strong>
            Fix all 🔴 Critical issues first — these have the highest SEO impact. Then move to 🟡 Medium priorities. Most 🔴 Critical issues can be resolved in under 2 hours and typically produce visible ranking improvements within 4-6 weeks of Google re-crawling your site. Use the Rank #1 Roadmap tool for a full content and backlink strategy.
          </div>`;
        out.classList.remove('hidden');
      }
    },

    /* ===== RANK #1 ROADMAP STRATEGIST ===== */
    roadmap: {
      title: 'Rank #1 Roadmap Strategist',
      sub: 'Enter your niche and receive a customized, step-by-step strategy to reach #1 on Google.',
      render: ()=>`
        <form class="tool-form" data-action="roadmap">
          <label>Your Niche / Category
            <input name="niche" required placeholder="e.g. organic dog food for small breeds, SaaS project management tools">
          </label>
          <label>Your Current Situation
            <select name="stage">
              <option value="new">Brand new site (0-6 months old)</option>
              <option value="growing">Growing site (6 months – 2 years)</option>
              <option value="established">Established site (2+ years)</option>
            </select>
          </label>
          <label>Biggest Challenge
            <select name="challenge">
              <option value="traffic">Not enough organic traffic</option>
              <option value="rankings">Stuck on page 2-3 of Google</option>
              <option value="content">Don't know what content to create</option>
              <option value="backlinks">Struggling to build backlinks</option>
              <option value="technical">Technical SEO issues</option>
            </select>
          </label>
          <button class="btn btn-primary" type="submit">🗺️ Build My Rank #1 Roadmap</button>
        </form>
        <div id="out" class="hidden"></div>`,
      run:(form,out)=>{
        const niche = form.niche.value.trim();
        const stage = form.stage.value;
        const challenge = form.challenge.value;
        const h = hash(niche);

        const stageName = {new:'New Site',growing:'Growing Site',established:'Established Site'}[stage];

        // Generate niche-specific keywords
        const baseKws = niche.toLowerCase().split(/\s+/).slice(0,3);
        const kwVariants = [
          `best ${niche}`,
          `${niche} guide`,
          `how to choose ${niche}`,
          `${niche} for beginners`,
          `${niche} review 2025`,
          `top ${niche} tips`,
          `${niche} vs alternatives`,
          `cheap ${niche}`,
          `${niche} near me`,
          `${niche} comparison`,
        ];
        const selectedKws = kwVariants.filter((_,i)=>(h+i)%3<2).slice(0,6);

        // Stage-specific timeline
        const timeline = {
          new: '6–12 months to first page 1 rankings',
          growing: '2–4 months to page 1 for mid-difficulty keywords',
          established: '4–8 weeks to improve existing page 1 rankings'
        }[stage];

        const contentGaps = [
          `"${niche} complete guide" — a 3,000+ word pillar page covering everything a beginner needs to know`,
          `"Best ${niche} for [specific audience]" — comparison posts that target buyer-intent keywords`,
          `"${niche} FAQ" — a dedicated FAQ page targeting People Also Ask questions`,
          `Case studies or success stories using ${niche} — builds trust and attracts editorial links`,
          `"${niche} vs [alternative]" comparison — captures high-intent searchers who are comparing options`,
        ];
        const backlinkStrats = {
          new:[
            'Guest post on 3-5 niche blogs per month — focus on sites with DR 30+ in your space',
            'HARO (Help A Reporter Out) — respond to journalist queries for free editorial links',
            'Resource page link building — find "top tools for [niche]" pages and get listed',
            'Create a free tool, template, or dataset that naturally attracts links',
          ],
          growing:[
            'Broken link building — find dead links on competitor-adjacent pages and offer your content as a replacement',
            'Podcast guesting — be a guest on 2-3 podcasts in your niche per month for brand + links',
            'Digital PR — create a data study or original research that journalists want to cite',
            'Skyscraper technique — find the most linked content in your niche and create a definitively better version',
          ],
          established:[
            'Reclaim unlinked brand mentions — find sites that mention you without linking and ask them to add the link',
            'Competitor backlink gap — export competitors\' backlink profiles and target sites linking to them but not you',
            'Content syndication to Medium, LinkedIn Articles, and industry publications',
            'Build a content hub around your best-performing pages to consolidate authority',
          ]
        }[stage];

        const technicalPriorities = [
          'Fix all Core Web Vitals — target LCP < 2.5s, FID < 100ms, CLS < 0.1 (use PageSpeed Insights)',
          'Implement a logical internal linking structure — every page should be reachable in 3 clicks from the homepage',
          'Add JSON-LD schema markup for your content type (Article, Product, FAQ, LocalBusiness)',
          'Create and submit an XML sitemap to Google Search Console',
          'Optimize your URL structure — keep URLs short, keyword-rich, and descriptive (no random IDs)',
          'Ensure every page has a unique title tag and meta description targeting a specific keyword',
        ];

        const challengeTip = {
          traffic: `<div class="roadmap-step"><div class="step-head"><div class="step-num">⚡</div><div class="step-title">Your Priority: Driving Traffic Fast</div></div><p>Since traffic is your main challenge, focus on "low-hanging fruit" first: target long-tail keywords with difficulty under 35. Write 1,500–2,500 word posts targeting ONE specific long-tail keyword each. Five well-optimized long-tail posts will consistently outperform one attempt at a broad competitive keyword for a site in your stage.</p></div>`,
          rankings: `<div class="roadmap-step"><div class="step-head"><div class="step-num">⚡</div><div class="step-title">Your Priority: Moving from Page 2 to Page 1</div></div><p>If you're stuck on page 2–3, the fix is usually one of three things: your content needs to be more comprehensive (add depth, not just length), your page needs more internal links pointing to it, or you need 5-10 more quality backlinks than whoever is currently in position 10. Use the Keyword Explorer to check your target page's difficulty and the Backlink Analyzer to see what it takes to beat #10.</p></div>`,
          content: `<div class="roadmap-step"><div class="step-head"><div class="step-num">⚡</div><div class="step-title">Your Priority: Building a Content Strategy</div></div><p>Start with one comprehensive "pillar page" that covers your entire topic (2,500–5,000 words), then create 8–12 "cluster posts" that answer specific questions around that topic and link back to the pillar. This topical authority structure is exactly how sites like NerdWallet and Wirecutter dominate every category they enter.</p></div>`,
          backlinks: `<div class="roadmap-step"><div class="step-head"><div class="step-num">⚡</div><div class="step-title">Your Priority: Building Your First 50 Links</div></div><p>For link building, lead with value: create the single best resource in your niche (a free tool, comprehensive guide, or original data study), then manually pitch it to relevant blogs and resource pages. Even 10-15 genuine links from relevant DR30+ sites will dramatically shift your rankings. Quantity matters far less than relevance and authority.</p></div>`,
          technical: `<div class="roadmap-step"><div class="step-head"><div class="step-num">⚡</div><div class="step-title">Your Priority: Technical SEO Fixes</div></div><p>Run the Deep Site Auditor tool first for a specific list of issues. The most impactful technical fixes are almost always: fixing Core Web Vitals (especially LCP), ensuring every page is crawlable and indexable, implementing canonical tags, and adding schema markup. Once technical issues are resolved, content and links will start working much more effectively.</p></div>`,
        }[challenge];

        out.innerHTML = `
          <div class="tool-output" style="margin-bottom:16px">
            <strong>🗺️ Your Rank #1 Roadmap — ${niche}</strong><br/>
            <span style="color:var(--muted);font-size:.85rem">Personalized for: ${stageName} · Estimated timeline: ${timeline}</span>
          </div>

          ${challengeTip}

          <div class="roadmap-step">
            <div class="step-head"><div class="step-num">1</div><div class="step-title">Content Gaps to Fill First</div></div>
            <p>These are the highest-priority content types that are consistently underserved in the <strong>${niche}</strong> space and are actively searched by your target audience:</p>
            <ul>${contentGaps.map(g=>`<li>${g}</li>`).join('')}</ul>
          </div>

          <div class="roadmap-step">
            <div class="step-head"><div class="step-num">2</div><div class="step-title">Keywords to Target Right Now</div></div>
            <p>Start with these specific keyword angles — they're designed to match your current authority level and have realistic ranking potential:</p>
            <div class="kw-tags">${selectedKws.map(k=>`<span class="kw-tag">🔍 ${k}</span>`).join('')}</div>
            <p style="margin-top:10px;font-size:.82rem;color:var(--muted)">Use the Keyword Explorer tool to check exact volume and difficulty for each of these before writing.</p>
          </div>

          <div class="roadmap-step">
            <div class="step-head"><div class="step-num">3</div><div class="step-title">Backlink Strategy for Your Niche</div></div>
            <ul>${backlinkStrats.map(s=>`<li>${s}</li>`).join('')}</ul>
          </div>

          <div class="roadmap-step">
            <div class="step-head"><div class="step-num">4</div><div class="step-title">Technical SEO Priorities</div></div>
            <ul>${technicalPriorities.map(t=>`<li>${t}</li>`).join('')}</ul>
          </div>

          <div class="roadmap-step">
            <div class="step-head"><div class="step-num">5</div><div class="step-title">Your 90-Day Action Plan</div></div>
            <ul>
              <li><strong>Days 1–30:</strong> Fix all technical issues (use the Site Auditor). Publish your pillar page + 3 cluster posts targeting long-tail keywords from the list above.</li>
              <li><strong>Days 31–60:</strong> Begin link building with 2 guest posts and 3 HARO responses per week. Publish 2 more cluster posts. Set up Google Search Console and monitor impressions.</li>
              <li><strong>Days 61–90:</strong> Analyze what's gaining traction. Double down on your best-performing content with updates and additional backlinks. Publish the FAQ and comparison content gap pieces.</li>
            </ul>
          </div>

          <div class="tool-output" style="margin-top:6px">
            <strong>💡 Pro Tip:</strong> SEO compounds. The sites that dominate their niche didn't get there by publishing 100 mediocre posts — they published 20 exceptional, comprehensive pieces that solved real problems better than anything else on the internet. Quality and consistency over 90 days beats a sporadic burst of activity every time.
          </div>`;
        out.classList.remove('hidden');
      }
    },

    /* ===== AI SEO WRITER ===== */
    writer: {
      title: 'AI SEO Writer',
      sub: 'Generate optimized blog intros, meta descriptions, and ad copy in seconds.',
      render: ()=>`
        <form class="tool-form" data-action="writer">
          <label>Content Type
            <select name="template">
              <option value="blog">Blog Post Introduction</option>
              <option value="meta">Meta Description</option>
              <option value="ad">Ad Copy</option>
              <option value="product">Product Description</option>
            </select>
          </label>
          <label>Target Keyword / Topic
            <input name="topic" required placeholder="e.g. best running shoes for flat feet">
          </label>
          <label>Tone
            <select name="tone">
              <option>Professional</option>
              <option>Friendly</option>
              <option>Persuasive</option>
              <option>Authoritative</option>
            </select>
          </label>
          <button class="btn btn-primary" type="submit">✍️ Generate Content</button>
        </form>
        <div class="tool-output hidden" id="out"></div>`,
      run:(form,out)=>{
        const t = form.template.value;
        const k = form.topic.value.trim();
        const tn = form.tone.value;
        const year = new Date().getFullYear();
        const samples = {
          blog: `# The Definitive Guide to ${k} (${year} Edition)\n\nIn an increasingly competitive landscape, getting ${k} right isn't a nice-to-have — it's the difference between scaling organically and paying for every single click. Whether you're starting from scratch or refining a strategy that's already working, this ${tn.toLowerCase()} guide walks you through the frameworks, common mistakes, and tactical wins that consistently move the needle on Google.\n\nBy the end, you'll have a complete playbook you can implement this week — backed by data, not opinions.`,
          meta: `Discover the complete guide to ${k} for ${year}. ${tn} expert insights, proven strategies, and step-by-step advice — trusted by thousands of professionals. Read our in-depth breakdown and get actionable results today. (${Math.floor(Math.random()*20+140)} characters)`,
          ad: `🚀 Finally Master ${k}\n\n${tn} strategies from practitioners who've done it. Trusted by 40,000+ professionals.\n\n✓ Proven step-by-step framework\n✓ Real-world case studies\n✓ Start seeing results in 30 days\n\n→ Get instant access — free to start`,
          product: `Introducing the definitive solution for ${k}. Designed for ${tn.toLowerCase()} professionals who demand results, not excuses. Built on real-world insights, peer-tested, and engineered to give you a measurable edge — from day one.\n\n★★★★★ "Finally, something that actually works." — Verified buyer`
        };
        out.textContent = samples[t];
        out.classList.remove('hidden');
      }
    },

    /* ===== KEYWORD EXPLORER ===== */
    keywords: {
      title: 'Keyword Explorer',
      sub: 'Analyze volume, difficulty, CPC, and intent for any keyword — uncover hidden opportunities.',
      render: ()=>`
        <form class="tool-form" data-action="keywords">
          <label>Seed Keyword <input name="kw" required placeholder="e.g. ai marketing tools"></label>
          <label>Target Market
            <select name="m">
              <option>United States</option><option>United Kingdom</option>
              <option>Australia</option><option>Canada</option>
              <option>Germany</option><option>India</option>
            </select>
          </label>
          <button class="btn btn-primary" type="submit">🔍 Analyze Keyword</button>
        </form>
        <div id="out" class="hidden"></div>`,
      run:(form,out)=>{
        const kw = form.kw.value.trim();
        const h = hash(kw);
        const vol = 800 + (h%48000);
        const kd = 18 + (h%72);
        const cpc = (0.4+(h%900)/100).toFixed(2);
        const comp = ['Low','Medium','High'][h%3];
        const intent = ['Informational','Commercial','Transactional','Navigational'][h%4];
        const variants = ['best','top','how to','vs','guide','cheap','free','tools'].slice(0,5).map(p=>`${p} ${kw}`);
        out.innerHTML = `
          <div class="metric-grid">
            ${metricBar('Monthly Volume', vol.toLocaleString(), vol)}
            ${metricBar('Difficulty', kd, 100)}
            <div class="metric"><div class="v">$${cpc}</div><div class="l">Avg. CPC</div></div>
            <div class="metric"><div class="v">${intent}</div><div class="l">Search Intent</div></div>
            <div class="metric"><div class="v">${comp}</div><div class="l">Competition</div></div>
            <div class="metric"><div class="v">${kd<40?'High':kd<65?'Medium':'Low'}</div><div class="l">Opportunity</div></div>
          </div>
          <div class="table-wrap">
            <table class="data">
              <tr><th>Keyword Variant</th><th>Est. Volume</th><th>Difficulty</th><th>Opportunity</th></tr>
              ${variants.map((v,i)=>{
                const vh = hash(v); const vvol = 100+(vh%8000); const vkd = 10+(vh%60);
                return `<tr><td>${v}</td><td>${vvol.toLocaleString()}/mo</td><td>${vkd}/100</td><td>${vkd<35?'🟢 High':vkd<55?'🟡 Medium':'🔴 Low'}</td></tr>`;
              }).join('')}
            </table>
          </div>`;
        out.classList.remove('hidden');
      }
    },

    /* ===== BACKLINK ANALYZER ===== */
    backlinks: {
      title: 'Backlink Analyzer',
      sub: 'Inspect referring domains, authority scores, and anchor text for any URL.',
      render: ()=>`
        <form class="tool-form" data-action="backlinks">
          <label>URL to Analyze <input name="url" type="url" required placeholder="https://competitor.com"></label>
          <button class="btn btn-primary" type="submit">🔗 Analyze Backlinks</button>
        </form>
        <div id="out" class="hidden"></div>`,
      run:(form,out)=>{
        const url = form.url.value.trim();
        const h = hash(url);
        const dr = 20+(h%70); const bl = 50+(h%4950); const rd = 10+(h%490);
        const toxic = Math.round(bl*0.04+(h%30));
        const anchors = [
          ['brand name', Math.round(bl*.32)],
          ['click here', Math.round(bl*.18)],
          ['target keyword', Math.round(bl*.24)],
          ['URL (naked)', Math.round(bl*.15)],
          ['other', Math.round(bl*.11)],
        ];
        out.innerHTML = `
          <div class="metric-grid">
            ${metricBar('Domain Rating', dr)}
            <div class="metric"><div class="v">${bl.toLocaleString()}</div><div class="l">Total Backlinks</div></div>
            <div class="metric"><div class="v">${rd.toLocaleString()}</div><div class="l">Referring Domains</div></div>
            <div class="metric"><div class="v">${toxic}</div><div class="l">Toxic Links</div></div>
          </div>
          <h4 style="margin:18px 0 10px;font-size:.82rem;text-transform:uppercase;letter-spacing:.06em;color:var(--muted)">Anchor Text Distribution</h4>
          <div class="table-wrap"><table class="data">
            <tr><th>Anchor Text Type</th><th>Count</th><th>% of Total</th></tr>
            ${anchors.map(([t,c])=>`<tr><td>${t}</td><td>${c}</td><td>${((c/bl)*100).toFixed(1)}%</td></tr>`).join('')}
          </table></div>
          <div class="tool-output" style="margin-top:14px">${dr>60?'✓ Strong domain authority — focus on maintaining link quality.':dr>35?'⚠ Moderate authority — prioritize 10–20 high-quality links per month to grow DR.':'⚠ Low domain authority — focus entirely on earning links from DR30+ sites in your niche. Quantity matters less than relevance right now.'}</div>`;
        out.classList.remove('hidden');
      }
    },

    /* ===== COMPETITOR GAP ===== */
    gap: {
      title: 'Competitor Gap Analysis',
      sub: 'Uncover the keywords your competitors rank for that you don\'t — your biggest opportunities.',
      render: ()=>`
        <form class="tool-form" data-action="gap">
          <label>Your Domain <input name="own" required placeholder="yourdomain.com"></label>
          <label>Competitor Domain <input name="comp" required placeholder="competitor.com"></label>
          <button class="btn btn-primary" type="submit">📊 Find Gaps</button>
        </form>
        <div id="out" class="hidden"></div>`,
      run:(form,out)=>{
        const own = form.own.value.trim().replace(/https?:\/\//,'');
        const comp = form.comp.value.trim().replace(/https?:\/\//,'');
        const h = hash(comp);
        const gaps = [
          [`best ${comp.split('.')[0]} alternatives`, 1200+(h%8000), 32+(h%40), '🟢 High'],
          [`how to use ${comp.split('.')[0]}`, 800+(h%5000), 28+(h%35), '🟢 High'],
          [`${comp.split('.')[0]} pricing`, 600+(h%4000), 38+(h%30), '🟡 Medium'],
          [`${comp.split('.')[0]} review`, 400+(h%3000), 45+(h%35), '🟡 Medium'],
          [`${comp.split('.')[0]} vs ${own.split('.')[0]}`, 300+(h%2000), 25+(h%25), '🟢 High'],
        ];
        out.innerHTML = `
          <div class="metric-grid">
            <div class="metric"><div class="v">${5+(h%45)}</div><div class="l">Gap Keywords Found</div></div>
            <div class="metric"><div class="v">${(3200+(h%40000)).toLocaleString()}</div><div class="l">Missed Monthly Visits</div></div>
            <div class="metric"><div class="v">${2+(h%8)}</div><div class="l">Quick-Win Opportunities</div></div>
          </div>
          <div class="table-wrap" style="margin-top:16px"><table class="data">
            <tr><th>Gap Keyword</th><th>Est. Volume</th><th>Difficulty</th><th>Opportunity</th></tr>
            ${gaps.map(([k,v,d,o])=>`<tr><td>${k}</td><td>${v.toLocaleString()}/mo</td><td>${d}/100</td><td>${o}</td></tr>`).join('')}
          </table></div>
          <div class="tool-output" style="margin-top:14px"><strong>Priority recommendation:</strong> Target the 🟢 High Opportunity gaps first. Create dedicated, in-depth pages for each one — these keywords already have proven search demand and your competitor's presence confirms there's audience intent. You just need to show up with better content.</div>`;
        out.classList.remove('hidden');
      }
    },

    /* ===== SERP SIMULATOR ===== */
    serp: {
      title: 'SERP Simulator',
      sub: 'Preview exactly how your page looks in Google — and check for rich result eligibility.',
      render: ()=>`
        <form class="tool-form" data-action="serp">
          <label>Page Title (max 60 chars) <input name="t" required maxlength="70" placeholder="The Best Running Shoes for Flat Feet (2025 Guide)"></label>
          <label>Meta Description (max 160 chars) <input name="d" required maxlength="170" placeholder="Discover the top 10 running shoes designed for flat feet in 2025..."></label>
          <label>Page URL <input name="u" required placeholder="https://example.com/running-shoes-flat-feet"></label>
          <button class="btn btn-primary" type="submit">🎯 Preview SERP Result</button>
        </form>
        <div id="out" class="hidden"></div>`,
      run:(form,out)=>{
        const t=form.t.value,d=form.d.value,u=form.u.value;
        const tLen=t.length,dLen=d.length;
        const tOk=tLen>=45&&tLen<=60,dOk=dLen>=130&&dLen<=160;
        out.innerHTML = `
          <div class="tool-output" style="font-family:Arial,sans-serif;background:var(--bg);border-radius:10px">
            <div style="color:#8ab4f8;font-size:.8rem;margin-bottom:3px">${u}</div>
            <div style="color:#7dd3fc;font-size:1.15rem;margin:4px 0;font-weight:500">${t.substring(0,65)}${t.length>65?'...':''}</div>
            <div style="color:#99b0c8;font-size:.88rem;line-height:1.5">${d.substring(0,160)}${d.length>160?'...':''}</div>
          </div>
          <div class="metric-grid">
            <div class="metric"><div class="v" style="color:${tOk?'var(--cyan)':'#f87171'}">${tLen}/60</div><div class="l">Title Length</div></div>
            <div class="metric"><div class="v" style="color:${dOk?'var(--cyan)':'#f87171'}">${dLen}/160</div><div class="l">Description</div></div>
          </div>
          <div class="tool-output" style="margin-top:12px">
            ${tOk?'✓':'⚠'} Title: ${tOk?'Optimal length — good for click-through rates.':'Adjust to 45–60 characters for best results.'}<br/>
            ${dOk?'✓':'⚠'} Description: ${dOk?'Optimal length — will display fully in search results.':'Target 130–160 characters to avoid truncation.'}
          </div>`;
        out.classList.remove('hidden');
      }
    },

    /* ===== CONTENT OPTIMIZER ===== */
    optimizer: {
      title: 'Content Optimizer',
      sub: 'Score your content and get specific recommendations to outrank the competition.',
      render: ()=>`
        <form class="tool-form" data-action="optimizer">
          <label>Target Keyword <input name="kw" required placeholder="e.g. best project management tools"></label>
          <label>Your Content <textarea name="c" rows="7" required placeholder="Paste your article, blog post, or page content here..."></textarea></label>
          <button class="btn btn-primary" type="submit">🧠 Optimize Content</button>
        </form>
        <div id="out" class="hidden"></div>`,
      run:(form,out)=>{
        const kw=form.kw.value.trim().toLowerCase();
        const content=form.c.value.trim();
        const words=content.split(/\s+/).filter(w=>w.length>0).length;
        const sentences=Math.max(1,(content.match(/[.!?]+/g)||[]).length);
        const kwCount=(content.toLowerCase().match(new RegExp(kw.replace(/[.*+?^${}()|[\]\\]/g,'\\$&'),'g'))||[]).length;
        const kwDensity=words>0?((kwCount/words)*100).toFixed(1):0;
        const hasH1=/^#\s/.test(content)||/h1/i.test(content);
        const flesch=Math.max(0,Math.min(100,(206.835-1.015*(words/sentences)-84.6*(1.55)).toFixed(0)));
        const lengthScore=words>=1500?100:words>=800?75:words>=400?50:25;
        const kwScore=kwDensity>=0.5&&kwDensity<=2.5?100:kwDensity<0.5?40:60;
        const readScore=parseInt(flesch);
        const structScore=hasH1?80:40;
        const overall=Math.round((lengthScore+kwScore+readScore+structScore)/4);

        out.innerHTML = `
          <div class="metric-grid">
            ${metricBar('Overall Score', overall)}
            ${metricBar('Content Length', lengthScore)}
            ${metricBar('Keyword Usage', kwScore)}
            ${metricBar('Readability', Math.min(100,readScore))}
            <div class="metric"><div class="v">${words}</div><div class="l">Word Count</div></div>
            <div class="metric"><div class="v">${kwDensity}%</div><div class="l">KW Density</div></div>
          </div>
          <div class="tool-output" style="margin-top:14px">
            ${words<800?`⚠ <strong>Content too short</strong> (${words} words) — Top-ranking pages in most niches have 1,200–2,500+ words. Add more depth, examples, and FAQs.\n`:'✓ Content length looks solid.\n'}
            ${kwDensity<0.5?`⚠ <strong>Keyword density low</strong> (${kwDensity}%) — Mention "${kw}" more naturally throughout. Aim for 0.8–1.5% density.\n`:kwDensity>2.5?`⚠ <strong>Keyword stuffing risk</strong> (${kwDensity}%) — Reduce to 0.8–1.5% and use semantic variations instead.\n`:`✓ Keyword density is healthy (${kwDensity}%).\n`}
            ${!hasH1?'⚠ Add an H1 heading containing your target keyword at the top of your content.\n':'✓ Heading structure detected.\n'}
            ${readScore<50?'⚠ Readability needs work — use shorter sentences (15–20 words max) and avoid jargon.':'✓ Content is readable for a broad audience.'}
          </div>`;
        out.classList.remove('hidden');
      }
    },

    /* ===== SCHEMA GENERATOR ===== */
    schema: {
      title: 'Schema Markup Generator',
      sub: 'Generate valid JSON-LD structured data to activate rich results in Google.',
      render: ()=>`
        <form class="tool-form" data-action="schema">
          <label>Schema Type
            <select name="type">
              <option value="article">Article</option>
              <option value="faq">FAQ Page</option>
              <option value="product">Product</option>
              <option value="local">Local Business</option>
            </select>
          </label>
          <label>Title / Business Name <input name="title" required placeholder="e.g. Complete Guide to SEO"></label>
          <label>URL <input name="url" required placeholder="https://yoursite.com/page"></label>
          <label>Description / Author / Price <input name="extra" placeholder="Extra details (author, price, city, etc.)"></label>
          <button class="btn btn-primary" type="submit">⚙️ Generate Schema</button>
        </form>
        <div id="out" class="hidden"></div>`,
      run:(form,out)=>{
        const {type,title,url,extra}=form;
        const schemas={
          article:`{\n  "@context": "https://schema.org",\n  "@type": "Article",\n  "headline": "${title.value}",\n  "url": "${url.value}",\n  "author": { "@type": "Person", "name": "${extra.value||'Your Name'}" },\n  "datePublished": "${new Date().toISOString().split('T')[0]}",\n  "description": "Your meta description here"\n}`,
          faq:`{\n  "@context": "https://schema.org",\n  "@type": "FAQPage",\n  "mainEntity": [\n    {\n      "@type": "Question",\n      "name": "What is ${title.value}?",\n      "acceptedAnswer": {\n        "@type": "Answer",\n        "text": "Add your answer here for rich result eligibility."\n      }\n    }\n  ]\n}`,
          product:`{\n  "@context": "https://schema.org",\n  "@type": "Product",\n  "name": "${title.value}",\n  "url": "${url.value}",\n  "offers": {\n    "@type": "Offer",\n    "price": "${extra.value||'9.99'}",\n    "priceCurrency": "USD",\n    "availability": "https://schema.org/InStock"\n  }\n}`,
          local:`{\n  "@context": "https://schema.org",\n  "@type": "LocalBusiness",\n  "name": "${title.value}",\n  "url": "${url.value}",\n  "address": {\n    "@type": "PostalAddress",\n    "addressLocality": "${extra.value||'Your City'}"\n  }\n}`,
        };
        out.innerHTML = `<div class="tool-output" style="font-family:monospace;font-size:.85rem">${schemas[type.value].replace(/</g,'&lt;').replace(/>/g,'&gt;')}</div><p style="margin-top:10px;font-size:.85rem;color:var(--muted)">Copy this into a &lt;script type="application/ld+json"&gt; tag in your page &lt;head&gt;.</p>`;
        out.classList.remove('hidden');
      }
    },

    /* ===== ROI CALCULATOR ===== */
    roi: {
      title: 'SEO ROI Calculator',
      sub: 'Project the financial return from your SEO investment based on your niche and goals.',
      render: ()=>`
        <form class="tool-form" data-action="roi">
          <label>Monthly SEO Budget ($) <input name="invest" type="number" required min="0" placeholder="e.g. 500"></label>
          <label>Current Monthly Organic Visitors <input name="visitors" type="number" required min="0" placeholder="e.g. 1000"></label>
          <label>Expected Traffic Growth (%) <input name="growth" type="number" required min="0" placeholder="e.g. 30"></label>
          <label>Conversion Rate (%) <input name="conv" type="number" step="0.1" required min="0" placeholder="e.g. 2.5"></label>
          <label>Avg. Order / Lead Value ($) <input name="value" type="number" required min="0" placeholder="e.g. 150"></label>
          <button class="btn btn-primary" type="submit">💰 Calculate ROI</button>
        </form>
        <div id="out" class="hidden"></div>`,
      run:(form,out)=>{
        const inv=parseFloat(form.invest.value)||0;
        const v=parseFloat(form.visitors.value)||0;
        const g=parseFloat(form.growth.value)||0;
        const c=parseFloat(form.conv.value)/100||0;
        const val=parseFloat(form.value.value)||0;
        const newVisitors=v*(1+g/100);
        const conversions=newVisitors*c;
        const rev=conversions*val;
        const profit=rev-inv;
        const roi=inv?((profit/inv)*100).toFixed(0):0;
        const breakEven=inv&&rev?Math.ceil(inv/(rev/30)):0;
        out.innerHTML = `
          <div class="metric-grid">
            <div class="metric"><div class="v">${Math.round(newVisitors).toLocaleString()}</div><div class="l">Projected Visitors</div></div>
            <div class="metric"><div class="v">${conversions.toFixed(0)}</div><div class="l">Est. Conversions</div></div>
            <div class="metric"><div class="v">$${rev.toLocaleString()}</div><div class="l">Monthly Revenue</div></div>
            <div class="metric"><div class="v">$${profit.toLocaleString()}</div><div class="l">Net Profit</div></div>
            <div class="metric"><div class="v">${roi}%</div><div class="l">ROI</div></div>
            <div class="metric"><div class="v">${breakEven} days</div><div class="l">Break-Even</div></div>
          </div>
          <div class="tool-output" style="margin-top:14px">${profit>0?`✓ Positive ROI — for every $1 invested, you're projected to earn $${(rev/inv).toFixed(2)} in revenue. Compound this over 12 months and you're looking at <strong>$${Math.round(rev*12).toLocaleString()} in annual organic revenue</strong>.`:'⚠ Negative ROI at these numbers. Consider reducing investment, increasing conversion rate, or targeting higher-value keywords to improve the model.'}</div>`;
        out.classList.remove('hidden');
      }
    },

    /* ===== META TAG GENERATOR ===== */
    meta: {
      title: 'Meta Tag Generator',
      sub: 'Craft optimized titles and descriptions with a live SERP preview.',
      render: ()=>`
        <form class="tool-form" data-action="meta">
          <label>Page Title <input name="t" required maxlength="70" placeholder="Up to 60 characters with your keyword first"></label>
          <label>Meta Description <input name="d" required maxlength="170" placeholder="130-160 chars with keyword + call to action"></label>
          <label>Page URL <input name="u" required placeholder="https://example.com/your-page-slug"></label>
          <button class="btn btn-primary" type="submit">🏷️ Generate Preview</button>
        </form>
        <div id="out" class="hidden"></div>`,
      run:(form,out)=>{
        const t=form.t.value,d=form.d.value,u=form.u.value;
        out.innerHTML = `
          <div class="tool-output" style="font-family:Arial,sans-serif">
            <div style="color:#8ab4f8;font-size:.78rem">${u}</div>
            <div style="color:#7dd3fc;font-size:1.1rem;margin:4px 0;font-weight:500">${t}</div>
            <div style="color:#99b0c8;font-size:.88rem">${d}</div>
          </div>
          <div class="metric-grid">
            <div class="metric"><div class="v" style="color:${t.length<=60?'var(--cyan)':'#f87171'}">${t.length}/60</div><div class="l">Title Length</div></div>
            <div class="metric"><div class="v" style="color:${d.length<=160?'var(--cyan)':'#f87171'}">${d.length}/160</div><div class="l">Description</div></div>
          </div>`;
        out.classList.remove('hidden');
      }
    },

    /* ===== READABILITY SCORER ===== */
    readability: {
      title: 'Readability Scorer',
      sub: 'Analyze reading level and get actionable suggestions to improve comprehension and dwell time.',
      render: ()=>`
        <form class="tool-form" data-action="readability">
          <label>Content to Analyze <textarea name="c" rows="7" required placeholder="Paste your article or blog post here..."></textarea></label>
          <button class="btn btn-primary" type="submit">📖 Score Readability</button>
        </form>
        <div id="out" class="hidden"></div>`,
      run:(form,out)=>{
        const text=form.c.value.trim();
        const words=text.split(/\s+/).filter(w=>w.length>0).length;
        const sentences=Math.max(1,(text.match(/[.!?]+/g)||[]).length);
        const syllables=Math.round(words*1.55);
        const flesch=parseFloat((206.835-1.015*(words/sentences)-84.6*(syllables/words)).toFixed(1));
        const grade=parseFloat(((0.39*(words/sentences))+(11.8*(syllables/words))-15.59).toFixed(1));
        const avgWords=(words/sentences).toFixed(1);
        const level=flesch>=70?'Easy (broad audience)':flesch>=50?'Moderate (general adult)':flesch>=30?'Difficult (educated adult)':'Very Difficult (academic)';
        out.innerHTML = `
          <div class="metric-grid">
            ${metricBar('Flesch Reading Ease', Math.max(0,Math.min(100,Math.round(flesch))))}
            <div class="metric"><div class="v">${grade}</div><div class="l">Grade Level</div></div>
            <div class="metric"><div class="v">${words}</div><div class="l">Word Count</div></div>
            <div class="metric"><div class="v">${sentences}</div><div class="l">Sentences</div></div>
            <div class="metric"><div class="v">${avgWords}</div><div class="l">Avg Words/Sentence</div></div>
          </div>
          <div class="tool-output" style="margin-top:14px">
            <strong>Reading Level:</strong> ${level}<br/><br/>
            ${flesch>60?'✓ Your content is easy to read — great for broad organic traffic.':'⚠ Consider shortening sentences to under 20 words and replacing technical jargon with plain language. Easier-to-read content typically gets lower bounce rates and higher dwell time, both of which influence rankings.'}
            ${parseFloat(avgWords)>20?`\n\n⚠ Average sentence length is ${avgWords} words — aim for under 20 words per sentence.`:''}
          </div>`;
        out.classList.remove('hidden');
      }
    }
  };

  // ── LAUNCH TOOL ────────────────────────────────────────
  $$('.tool-card').forEach(card=>{
    const btn = card.querySelector('button');
    if(!btn) return;
    btn.addEventListener('click', ()=>{
      const id = card.dataset.tool;
      const tool = tools[id];
      if(!tool) return;
      $('#workspaceTitle').textContent = tool.title;
      $('#workspaceSub').textContent = tool.sub;
      $('#workspaceBody').innerHTML = tool.render();

      const form = $('#workspaceBody form');
      if(form){
        form.addEventListener('submit', e=>{
          e.preventDefault();
          if(!canUse()) return;
          const out = $('#workspaceBody #out');
          if(!out) return;
          tool.run(form, out);
          consumeUse();
        });
      }
      setTimeout(()=>{
        document.getElementById('workspace').scrollIntoView({behavior:'smooth', block:'start'});
      }, 80);
    });
  });

  // ── LEGAL MODALS ───────────────────────────────────────
  const legalContent = {
    privacy: `<h2>Privacy Policy</h2>
      <p><em>Last updated: ${new Date().toLocaleDateString()}</em></p>
      <p>RankApex AI ("we", "us", "our") is committed to protecting your privacy. This policy explains how we handle information when you use our service.</p>
      <h3>1. Information We Collect</h3>
      <ul>
        <li>Technical data: browser type, device, anonymized IP address via third-party analytics</li>
        <li>Usage data: which tools are used (aggregate, not per-user)</li>
        <li>Content you submit to tools — processed entirely in your browser, never sent to our servers</li>
        <li>Contact form submissions if you choose to contact us</li>
      </ul>
      <h3>2. How We Use Information</h3>
      <p>We use data solely to operate, maintain, and improve the service, and to respond to your inquiries. We never sell personal information to third parties.</p>
      <h3>3. Local Storage</h3>
      <p>We use browser localStorage to track your free-tier usage count and Pro status on your device. This data never leaves your browser. Clearing your browser data resets your usage counter.</p>
      <h3>4. Google AdSense</h3>
      <p>We display advertisements via Google AdSense. Google may use cookies to serve ads based on your prior visits to this and other websites. You can opt out at <a href="https://adssettings.google.com" target="_blank" rel="noopener">adssettings.google.com</a>.</p>
      <h3>5. Your Rights (GDPR / CCPA)</h3>
      <p>You have the right to access, correct, delete, or restrict processing of your personal data. EU residents may contact their supervisory authority. California residents may request disclosure of data we hold about them.</p>
      <h3>6. Data Retention</h3>
      <p>Contact form inquiries are retained only as long as necessary to respond. All tool inputs are processed client-side and are never stored on our servers.</p>
      <h3>7. Children's Privacy</h3>
      <p>RankApex AI is not directed to children under 13. We do not knowingly collect data from minors.</p>
      <h3>8. Contact</h3>
      <p>For privacy requests: <a href="mailto:privacy@rankapex.ai">privacy@rankapex.ai</a></p>`,

    terms: `<h2>Terms of Service</h2>
      <p><em>Last updated: ${new Date().toLocaleDateString()}</em></p>
      <h3>1. Acceptance</h3>
      <p>By using RankApex AI, you agree to these Terms. If you disagree, please discontinue use of the service.</p>
      <h3>2. Service Description</h3>
      <p>RankApex AI provides browser-based SEO tools for informational and professional use. All tool outputs are simulations designed to guide strategy and should be verified against primary data sources before making major business decisions.</p>
      <h3>3. Free & Pro Tiers</h3>
      <p>Free users receive 5 total tool uses tracked via browser localStorage. Lifetime Pro access is a one-time purchase of $5 USD processed through Patreon. There are no monthly fees, subscriptions, or renewals for Pro users. Once purchased, access is permanent.</p>
      <h3>4. Acceptable Use</h3>
      <p>You agree not to: attempt to circumvent usage limits through technical manipulation, use the service for unlawful purposes, resell or redistribute tool outputs as your own platform, or attempt to reverse-engineer or scrape the service.</p>
      <h3>5. Intellectual Property</h3>
      <p>All site design, branding, and code are owned by RankApex AI. Generated outputs belong to you, the user, and may be used freely in your own projects.</p>
      <h3>6. No Warranty</h3>
      <p>The service is provided "as is" without warranties of any kind. Tool outputs are AI-assisted simulations for informational purposes only.</p>
      <h3>7. Limitation of Liability</h3>
      <p>To the maximum extent permitted by law, RankApex AI shall not be liable for indirect, incidental, or consequential damages arising from your use of the service.</p>
      <h3>8. Changes</h3>
      <p>We may update these Terms at any time. Continued use constitutes acceptance. We will note the "last updated" date above when changes are made.</p>
      <h3>9. Contact</h3>
      <p><a href="mailto:legal@rankapex.ai">legal@rankapex.ai</a></p>`,

    sitemap: `<h2>Sitemap</h2>
      <h3>Pages</h3>
      <ul>
        <li><a href="#home" onclick="document.querySelector('#legalModal').classList.remove('open');document.body.style.overflow=''">Home</a></li>
        <li><a href="#tools" onclick="document.querySelector('#legalModal').classList.remove('open');document.body.style.overflow=''">SEO Tools</a></li>
        <li><a href="#workspace" onclick="document.querySelector('#legalModal').classList.remove('open');document.body.style.overflow=''">Workspace</a></li>
        <li><a href="#pricing" onclick="document.querySelector('#legalModal').classList.remove('open');document.body.style.overflow=''">Pricing</a></li>
        <li><a href="#about" onclick="document.querySelector('#legalModal').classList.remove('open');document.body.style.overflow=''">About Us</a></li>
        <li><a href="#contact" onclick="document.querySelector('#legalModal').classList.remove('open');document.body.style.overflow=''">Contact</a></li>
      </ul>
      <h3>Tools Available</h3>
      <ul>${Object.entries(tools).map(([,v])=>`<li>${v.title}</li>`).join('')}</ul>`
  };

  $$('[data-modal]').forEach(a => a.addEventListener('click', e=>{
    e.preventDefault();
    const key = a.dataset.modal;
    if(legalContent[key]){
      $('#legalContent').innerHTML = legalContent[key];
      openModal('legalModal');
    }
  }));

  // ── INIT ──────────────────────────────────────────────
  updateUsageDisplay();

})();
